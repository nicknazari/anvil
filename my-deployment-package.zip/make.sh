zip -r ../my-deployment-package.zip .
echo ">>>> OUTPUTTING FILE TO../my-deployment-package.zip <<<<"
